<?php

namespace TestProject\Engine\Pattern;

trait Base
{
    final private function __construct() {}
    final private function __clone() {}
}
