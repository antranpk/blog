
<p style="font-size: 34px; text-align: center; color: red">You not admin!</p>
<p style="text-align: center"><a href="../../index.php" title="" style="text-decoration: none;text-align: center;font-size: 30px;">Home page >>></a></p>

